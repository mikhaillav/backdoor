from flask import Flask, render_template, request
import os
app = Flask(__name__)
pth = os.path.dirname(os.path.abspath(__file__))

@app.route('/', methods=['GET', 'POST'])
def index():
    f = open(pth + '\\command.txt', 'w+')
    f.write(request.form['data'])
    return render_template('./form.html')
    
@app.route('/get', methods=['GET', 'POST'])
def get():
    f = open(pth + '\\command.txt', 'r')  
    return f.read()

@app.route('/post', methods=['POST','GET'])
def post():
    s = request.data
    data = s.decode('UTF-8')
    print(data)
    return data 

app.run()

    